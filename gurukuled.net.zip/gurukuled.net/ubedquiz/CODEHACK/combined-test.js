const questions = [
    // Sample questions (replace with your 20 questions)
    { question: "What is the value of 7 × 8?", choices: ["54", "56", "64", "48"], answer: 1 },
    { question: "Which of the following is an even number?", choices: ["27", "45", "34", "19"], answer: 2 },
    { question: "How many sides does a hexagon have?", choices: ["4", "5", "6", "7"], answer: 2 },
    { question: "If you have 3 quarters, how much money do you have in total?", choices: ["50 cents", "75 cents", "100 cents", "25 cents"], answer: 1 },
    { question: "What is the place value of 5 in the number 5,672?", choices: ["Hundreds", "Tens", "Thousands", "Units"], answer: 1 },
    { question: "The sum of 23 and 58 is:", choices: ["71", "82", "81", "75"], answer: 1 },
    { question: "Which of these fractions is equivalent to 1/2?", choices: ["2/4", "1/3", "3/6", "Both a and c"], answer: 3 },
    { question: "What is 15% of 100?", choices: ["10", "15", "20", "25"], answer: 1 },
    { question: "Which shape has no corners?", choices: ["Triangle", "Circle", "Square", "Rectangle"], answer: 1 },
    { question: "How many minutes are there in 3 hours?", choices: ["120", "90", "180", "210"], answer: 2 },
    { question: "What is the boiling point of water?", choices: ["90°C", "100°C", "110°C", "120°C"], answer: 1 },
    { question: "What gas do plants release during photosynthesis?", choices: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], answer: 0 },
    { question: "Which planet is closest to the sun?", choices: ["Venus", "Mars", "Mercury", "Jupiter"], answer: 2 },
    { question: "What do we call an animal that eats both plants and meat?", choices: ["Herbivore", "Carnivore", "Omnivore", "Insectivore"], answer: 2 },
    { question: "How many legs does a spider have?", choices: ["6", "8", "10", "12"], answer: 1 },
    { question: "What force pulls objects toward the Earth?", choices: ["Magnetism", "Friction", "Gravity", "Momentum"], answer: 2 },
    { question: "Which part of the plant is responsible for photosynthesis?", choices: ["Roots", "Stem", "Leaves", "Flowers"], answer: 2 },
    { question: "Which organ pumps blood throughout the body?", choices: ["Lungs", "Heart", "Brain", "Kidney"], answer: 1 },
    { question: "What do we call the liquid part of blood?", choices: ["Cells", "Plasma", "Platelets", "Proteins"], answer: 1 },
    { question: "What is the name of our galaxy?", choices: ["Andromeda", "Milky Way", "Orion", "Nebula"], answer: 1 }
];

let currentQuestionIndex = 0;
let score = 0;
let timer;
const totalQuestions = questions.length;

function startQuiz() {
    showQuestion();
    startTimer();
}

function showQuestion() {
    const questionContainer = document.getElementById('question-container');
    const choicesContainer = document.getElementById('choices');
    const question = questions[currentQuestionIndex];

    questionContainer.innerHTML = `<h3>${question.question}</h3>`;
    choicesContainer.innerHTML = '';
    
    question.choices.forEach((choice, index) => {
        const button = document.createElement('button');
        button.textContent = choice;
        button.addEventListener('click', () => handleAnswer(index));
        choicesContainer.appendChild(button);
    });
}

function handleAnswer(selectedIndex) {
    const correctIndex = questions[currentQuestionIndex].answer;
    const emojiFeedback = document.getElementById('emoji-feedback');
    const choices = document.querySelectorAll('#choices button');
    
    if (selectedIndex === correctIndex) {
        score++;
        emojiFeedback.innerHTML = "🎉🎉🎉";
        document.body.classList.add('green-overlay', 'shake');
        setTimeout(() => {
            document.body.classList.remove('green-overlay', 'shake');
            emojiFeedback.innerHTML = "";
        }, 1000);
    } else {
        emojiFeedback.innerHTML = "👎❌";
        document.body.classList.add('red-overlay', 'shake');
        setTimeout(() => {
            document.body.classList.remove('red-overlay', 'shake');
            emojiFeedback.innerHTML = "";
        }, 1000);
    }

    choices.forEach((button, index) => {
        button.classList.remove('correct', 'incorrect');
        if (index === correctIndex) {
            button.classList.add('correct');
        } else if (index === selectedIndex) {
            button.classList.add('incorrect');
        }
    });

    document.getElementById('next-btn').style.display = 'inline-block';
    clearInterval(timer);
}

function startTimer() {
    const timerElement = document.getElementById('timer');
    let timeLeft = 60;
    
    timer = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(timer);
            handleAnswer(-1); // Assume timeout is wrong
        } else {
            timerElement.textContent = `Time left: ${timeLeft}s`;
            timeLeft--;
        }
    }, 1000);
}

document.getElementById('next-btn').addEventListener('click', () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < totalQuestions) {
        showQuestion();
        startTimer();
        document.getElementById('next-btn').style.display = 'none';
    } else {
        showScore();
    }
});

function showScore() {
    document.getElementById('quiz-container').innerHTML = `
        <h2>Quiz Completed!</h2>
        <p>Your final score is ${score} out of ${totalQuestions}.</p>
        <button onclick="window.location.reload()">Retry Quiz</button>
    `;
}

startQuiz();
