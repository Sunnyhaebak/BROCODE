const questions = [
    { question: "What is the perimeter of a rectangle with a length of 8 cm and a width of 5 cm?", answers: ["26 cm", "24 cm", "30 cm", "20 cm"], correct: "26 cm" },
    { question: "What is the area of a triangle with a base of 10 cm and a height of 6 cm?", answers: ["30 cm²", "60 cm²", "40 cm²", "20 cm²"], correct: "30 cm²" },
    { question: "If 15 ÷ 3 = 5, what is 5 × 3?", answers: ["10", "15", "18", "20"], correct: "15" },
    { question: "What is 2.5 + 4.75?", answers: ["7.25", "7.00", "8.25", "6.75"], correct: "7.25" },
    { question: "If a book costs $12 and you buy 4 books, what is the total cost?", answers: ["$36", "$40", "$48", "$50"], correct: "$48" },
    { question: "What is the value of 5²?", answers: ["10", "15", "25", "30"], correct: "25" },
    { question: "How many degrees are there in a full circle?", answers: ["180", "360", "90", "270"], correct: "360" },
    { question: "What is 50% of 90?", answers: ["45", "50", "40", "30"], correct: "45" },
    { question: "What is the result of 7 × (5 + 3)?", answers: ["56", "50", "64", "70"], correct: "56" },
    { question: "What is 1/4 of 100?", answers: ["20", "25", "30", "15"], correct: "25" }
];

let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 60;
let timer;
let hasAnswered = false; // Flag to check if an answer has been selected

const questionElement = document.getElementById('question');
const choicesElement = document.getElementById('choices');
const timeElement = document.getElementById('time');
const emojiFeedbackElement = document.getElementById('emoji-feedback');
const nextBtn = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');
const scoreElement = document.getElementById('score');

function startTimer() {
    timeLeft = 60;
    timer = setInterval(() => {
        timeLeft--;
        timeElement.textContent = timeLeft;
        if (timeLeft === 0) {
            clearInterval(timer);
            showNextQuestion();
        }
    }, 1000);
}

function showQuestion() {
    clearInterval(timer);
    startTimer();
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesElement.innerHTML = "";
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement('button');
        button.textContent = answer;
        button.onclick = () => selectAnswer(button, answer);
        choicesElement.appendChild(button);
    });
    emojiFeedbackElement.textContent = "";
    nextBtn.style.display = "none";
    hasAnswered = false; // Reset the flag for new question
}

function selectAnswer(button, answer) {
    if (hasAnswered) return; // Do nothing if an answer has already been selected

    clearInterval(timer);

    const currentQuestion = questions[currentQuestionIndex];
    const allButtons = document.querySelectorAll("#choices button");
    allButtons.forEach(btn => btn.classList.add("disabled"));
    
    if (answer === currentQuestion.correct) {
        emojiFeedbackElement.textContent = "🎉 Correct!";
        score++;
    } else {
        document.body.classList.add("shake");
        document.body.classList.add("red-overlay");
        emojiFeedbackElement.textContent = "❌ Wrong!";
        setTimeout(() => {
            document.body.classList.remove("shake");
            document.body.classList.remove("red-overlay");
        }, 500);
    }

    nextBtn.style.display = "block";
    hasAnswered = true; // Set the flag to true after answering
}

function showNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showFinalScore();
    }
}

function showFinalScore() {
    questionElement.style.display = 'none';
    choicesElement.style.display = 'none';
    timeElement.style.display = 'none';
    nextBtn.style.display = 'none';
    scoreContainer.style.display = 'block';
    scoreElement.textContent = score;
}

nextBtn.addEventListener('click', showNextQuestion);

showQuestion();
