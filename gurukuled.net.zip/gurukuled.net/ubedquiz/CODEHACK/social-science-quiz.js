const questions = [
    { question: "Who was the first President of the United States?", answers: ["George Washington", "Abraham Lincoln", "John Adams", "Thomas Jefferson"], correct: "George Washington" },
    { question: "Which continent is the largest?", answers: ["Africa", "Asia", "Europe", "South America"], correct: "Asia" },
    { question: "What do we call a map that shows countries and capitals?", answers: ["Physical map", "Political map", "Weather map", "Population map"], correct: "Political map" },
    { question: "What is the capital of India?", answers: ["Mumbai", "Kolkata", "Delhi", "Chennai"], correct: "Delhi" },
    { question: "Who wrote the national anthem of the United States?", answers: ["George Washington", "Thomas Jefferson", "Francis Scott Key", "Benjamin Franklin"], correct: "Francis Scott Key" },
    { question: "What do we call a person who studies the past?", answers: ["Historian", "Geographer", "Scientist", "Architect"], correct: "Historian" },
    { question: "Who discovered America in 1492?", answers: ["Ferdinand Magellan", "Christopher Columbus", "Marco Polo", "Vasco da Gama"], correct: "Christopher Columbus" },
    { question: "What is the largest ocean on Earth?", answers: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"], correct: "Pacific Ocean" },
    { question: "What is the tallest mountain in the world?", answers: ["K2", "Mount Everest", "Mount Kilimanjaro", "Mount Fuji"], correct: "Mount Everest" },
    { question: "Who fought for the rights of African Americans in the USA?", answers: ["Nelson Mandela", "Martin Luther King Jr.", "Mahatma Gandhi", "Abraham Lincoln"], correct: "Martin Luther King Jr." }
];

let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 60;
let timer;
let hasAnswered = false; // Flag to check if an answer has been selected

const questionElement = document.getElementById('question');
const choicesElement = document.getElementById('choices');
const timeElement = document.getElementById('time');
const emojiFeedbackElement = document.getElementById('emoji-feedback');
const nextBtn = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');
const scoreElement = document.getElementById('score');

function startTimer() {
    timeLeft = 60;
    timer = setInterval(() => {
        timeLeft--;
        timeElement.textContent = timeLeft;
        if (timeLeft === 0) {
            clearInterval(timer);
            showNextQuestion();
        }
    }, 1000);
}

function showQuestion() {
    clearInterval(timer);
    startTimer();
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesElement.innerHTML = "";
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement('button');
        button.textContent = answer;
        button.onclick = () => selectAnswer(button, answer);
        choicesElement.appendChild(button);
    });
    emojiFeedbackElement.textContent = "";
    nextBtn.style.display = "none";
    hasAnswered = false; // Reset the flag for new question
}

function selectAnswer(button, answer) {
    if (hasAnswered) return; // Do nothing if an answer has already been selected

    clearInterval(timer);

    const currentQuestion = questions[currentQuestionIndex];
    const allButtons = document.querySelectorAll("#choices button");
    allButtons.forEach(btn => btn.classList.add("disabled"));
    
    if (answer === currentQuestion.correct) {
        emojiFeedbackElement.textContent = "🎉 Correct!";
        score++;
    } else {
        document.body.classList.add("shake");
        document.body.classList.add("red-overlay");
        emojiFeedbackElement.textContent = "❌ Wrong!";
        setTimeout(() => {
            document.body.classList.remove("shake");
            document.body.classList.remove("red-overlay");
        }, 500);
    }

    nextBtn.style.display = "block";
    hasAnswered = true; // Set the flag to true after answering
}

function showNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showFinalScore();
    }
}

function showFinalScore() {
    questionElement.style.display = 'none';
    choicesElement.style.display = 'none';
    timeElement.style.display = 'none';
    nextBtn.style.display = 'none';
    scoreContainer.style.display = 'block';
    scoreElement.textContent = score;
}

nextBtn.addEventListener('click', showNextQuestion);

showQuestion();
