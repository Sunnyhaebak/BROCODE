const questions = [
    { question: "What is the boiling point of water?", answers: ["90°C", "100°C", "110°C", "120°C"], correct: "100°C" },
    { question: "What gas do plants release during photosynthesis?", answers: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], correct: "Oxygen" },
    { question: "Which planet is closest to the sun?", answers: ["Venus", "Mars", "Mercury", "Jupiter"], correct: "Mercury" },
    { question: "What do we call an animal that eats both plants and meat?", answers: ["Herbivore", "Carnivore", "Omnivore", "Insectivore"], correct: "Omnivore" },
    { question: "How many legs does a spider have?", answers: ["6", "8", "10", "12"], correct: "8" },
    { question: "What force pulls objects toward the Earth?", answers: ["Magnetism", "Friction", "Gravity", "Momentum"], correct: "Gravity" },
    { question: "Which part of the plant is responsible for photosynthesis?", answers: ["Roots", "Stem", "Leaves", "Flowers"], correct: "Leaves" },
    { question: "Which organ pumps blood throughout the body?", answers: ["Lungs", "Heart", "Brain", "Kidney"], correct: "Heart" },
    { question: "What do we call the liquid part of blood?", answers: ["Cells", "Plasma", "Platelets", "Proteins"], correct: "Plasma" },
    { question: "What is the name of our galaxy?", answers: ["Andromeda", "Milky Way", "Orion", "Nebula"], correct: "Milky Way" }
];

let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 60;
let timer;
let hasAnswered = false; // Flag to check if an answer has been selected

const questionElement = document.getElementById('question');
const choicesElement = document.getElementById('choices');
const timeElement = document.getElementById('time');
const emojiFeedbackElement = document.getElementById('emoji-feedback');
const nextBtn = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');
const scoreElement = document.getElementById('score');

function startTimer() {
    timeLeft = 60;
    timer = setInterval(() => {
        timeLeft--;
        timeElement.textContent = timeLeft;
        if (timeLeft === 0) {
            clearInterval(timer);
            showNextQuestion();
        }
    }, 1000);
}

function showQuestion() {
    clearInterval(timer);
    startTimer();
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesElement.innerHTML = "";
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement('button');
        button.textContent = answer;
        button.onclick = () => selectAnswer(button, answer);
        choicesElement.appendChild(button);
    });
    emojiFeedbackElement.textContent = "";
    nextBtn.style.display = "none";
    hasAnswered = false; // Reset the flag for new question
}

function selectAnswer(button, answer) {
    if (hasAnswered) return; // Do nothing if an answer has already been selected

    clearInterval(timer);

    const currentQuestion = questions[currentQuestionIndex];
    const allButtons = document.querySelectorAll("#choices button");
    allButtons.forEach(btn => btn.classList.add("disabled"));
    
    if (answer === currentQuestion.correct) {
        emojiFeedbackElement.textContent = "🎉 Correct!";
        score++;
    } else {
        document.body.classList.add("shake");
        document.body.classList.add("red-overlay");
        emojiFeedbackElement.textContent = "❌ Wrong!";
        setTimeout(() => {
            document.body.classList.remove("shake");
            document.body.classList.remove("red-overlay");
        }, 500);
    }

    nextBtn.style.display = "block";
    hasAnswered = true; // Set the flag to true after answering
}

function showNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showFinalScore();
    }
}

function showFinalScore() {
    questionElement.style.display = 'none';
    choicesElement.style.display = 'none';
    timeElement.style.display = 'none';
    nextBtn.style.display = 'none';
    scoreContainer.style.display = 'block';
    scoreElement.textContent = score;
}

nextBtn.addEventListener('click', showNextQuestion);

showQuestion();
