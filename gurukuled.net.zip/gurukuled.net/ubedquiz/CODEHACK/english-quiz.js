const questions = [
    { question: "What is the opposite of 'hot'?", answers: ["Cold", "Warm", "Boiling", "Lukewarm"], correct: "Cold" },
    { question: "Choose the correct spelling:", answers: ["Separate", "Seperate", "Seporate", "Seperat"], correct: "Separate" },
    { question: "Which word means the same as 'happy'?", answers: ["Sad", "Joyful", "Angry", "Tired"], correct: "Joyful" },
    { question: "What is the plural form of 'mouse'?", answers: ["Mouses", "Mice", "Mouses", "Mices"], correct: "Mice" },
    { question: "Fill in the blank: She ____ to the store yesterday.", answers: ["Go", "Goes", "Going", "Went"], correct: "Went" },
    { question: "What is the past tense of 'run'?", answers: ["Ran", "Runs", "Running", "Runned"], correct: "Ran" },
    { question: "Choose the correct sentence:", answers: ["She don’t like apples.", "She doesn’t like apples.", "She not like apples.", "She likes not apples."], correct: "She doesn’t like apples." },
    { question: "Which of these is a noun?", answers: ["Quickly", "Blue", "Apple", "Run"], correct: "Apple" },
    { question: "Fill in the blank: The cat sat ____ the mat.", answers: ["On", "In", "At", "By"], correct: "On" },
    { question: "What is the antonym of 'big'?", answers: ["Large", "Huge", "Small", "Tall"], correct: "Small" }
];

let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 60;
let timer;
let hasAnswered = false; // Flag to check if an answer has been selected

const questionElement = document.getElementById('question');
const choicesElement = document.getElementById('choices');
const timeElement = document.getElementById('time');
const emojiFeedbackElement = document.getElementById('emoji-feedback');
const nextBtn = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');
const scoreElement = document.getElementById('score');

function startTimer() {
    timeLeft = 60;
    timer = setInterval(() => {
        timeLeft--;
        timeElement.textContent = timeLeft;
        if (timeLeft === 0) {
            clearInterval(timer);
            showNextQuestion();
        }
    }, 1000);
}

function showQuestion() {
    clearInterval(timer);
    startTimer();
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesElement.innerHTML = "";
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement('button');
        button.textContent = answer;
        button.onclick = () => selectAnswer(button, answer);
        choicesElement.appendChild(button);
    });
    emojiFeedbackElement.textContent = "";
    nextBtn.style.display = "none";
    hasAnswered = false; // Reset the flag for new question
}

function selectAnswer(button, answer) {
    if (hasAnswered) return; // Do nothing if an answer has already been selected

    clearInterval(timer);

    const currentQuestion = questions[currentQuestionIndex];
    const allButtons = document.querySelectorAll("#choices button");
    allButtons.forEach(btn => btn.classList.add("disabled"));
    
    if (answer === currentQuestion.correct) {
        emojiFeedbackElement.textContent = "🎉 Correct!";
        score++;
    } else {
        document.body.classList.add("shake");
        document.body.classList.add("red-overlay");
        emojiFeedbackElement.textContent = "❌ Wrong!";
        setTimeout(() => {
            document.body.classList.remove("shake");
            document.body.classList.remove("red-overlay");
        }, 500);
    }

    nextBtn.style.display = "block";
    hasAnswered = true; // Set the flag to true after answering
}

function showNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showFinalScore();
    }
}

function showFinalScore() {
    questionElement.style.display = 'none';
    choicesElement.style.display = 'none';
    timeElement.style.display = 'none';
    nextBtn.style.display = 'none';
    scoreContainer.style.display = 'block';
    scoreElement.textContent = score;
}

nextBtn.addEventListener('click', showNextQuestion);

showQuestion();
