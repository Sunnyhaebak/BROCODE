const conceptsDetails = {
    "newton-laws": {
        title: "Newton's Laws of Motion",
        content: `<p><strong>Newton's First Law:</strong> An object at rest stays at rest, and an object in motion stays in motion with the same speed and in the same direction unless acted upon by an unbalanced force.</p>
                  <p><strong>Newton's Second Law:</strong> The force acting on an object is equal to the mass of that object times its acceleration. (F = ma)</p>
                  <p><strong>Newton's Third Law:</strong> For every action, there is an equal and opposite reaction.</p>`
    },
    "thermodynamics-laws": {
        title: "Laws of Thermodynamics",
        content: `<p><strong>First Law:</strong> Energy cannot be created or destroyed in an isolated system.</p>
                  <p><strong>Second Law:</strong> The entropy of any isolated system always increases.</p>
                  <p><strong>Third Law:</strong> The entropy of a system approaches a constant value as the temperature approaches absolute zero.</p>`
    },
    "relativity-theory": {
        title: "Theory of Relativity",
        content: `<p>The Theory of Relativity, formulated by Albert Einstein, consists of two theories:</p>
                  <ul>
                    <li><strong>Special Relativity:</strong> Deals with objects moving at constant speeds, particularly those moving close to the speed of light. Famous equation: E = mc².</li>
                    <li><strong>General Relativity:</strong> Describes the gravitational force as a curvature of space-time caused by mass and energy.</li>
                  </ul>`
    },
    "types-of-motion": {
        title: "Types of Motion",
        content: `<p><strong>Linear Motion:</strong> Movement in a straight line.</p>
                  <p><strong>Circular Motion:</strong> Movement in a circular path.</p>
                  <p><strong>Rotational Motion:</strong> Movement of an object around a center or axis.</p>
                  <p><strong>Oscillatory Motion:</strong> Repetitive back and forth motion, like a pendulum.</p>`
    }
};

document.querySelectorAll('.concept-card').forEach(card => {
    card.addEventListener('click', () => {
        const id = card.id;
        document.getElementById('modal-text').innerHTML = `
            <h2>${conceptsDetails[id].title}</h2>
            ${conceptsDetails[id].content}
        `;
        openModal();
    });
});

function openModal() {
    document.getElementById('modal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}
